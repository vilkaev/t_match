﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using Newtonsoft.Json;

namespace Function
{
    public class Request
    {
        public string HttpMethod { get; set; }
        public string Body { get; set; }
    }

    public class Response
    {
        public int StatusCode { get; set; }
        public string Body { get; set; }

        public Response(int statusCode, string body)
        {
            StatusCode = statusCode;
            Body = body;
        }
    }

    public class Handler
    {
        public Response FunctionHandler(Request request)
        {
            try
            {
                return new Response(200, CalculateBody(request.Body)); 
            } catch (Exception ex)
            {
                return new Response(500, ex.Message);
            }
            
        }

        string CalculateBody(string playersSet = "", int teamsCount = 2, int basketSize = 10)
        {
            List<Player> initBascket;
            List<Player> basket;

            if (string.IsNullOrEmpty(playersSet))
            {
                initBascket = Player.CreateTestBasket(basketSize);
            }
            else
            {
                //initBascket = JsonSerializer.Deserialize<List<Player>>(playersSet);
                initBascket = JsonConvert.DeserializeObject<List<Player>>(playersSet);

            }

            basket = new List<Player>(initBascket);
            char[] letters = "АБВГД".ToCharArray();


            List<Team> teams = new List<Team>();
            for (int i = 0; i < teamsCount; i++)
                teams.Add(new Team() { Name = letters[i] });

            while (basket.Count != 0)
            {
                teams.ForEach(c =>
                {
                    if (basket.Count > 0)
                        c.players.Add(SelectPlayerFromBasket(c, basket));
                }
                );


            }
            teams.ForEach(c => c.GetTeamScore());

            //var options = new JsonSerializerOptions
            //{
            //    Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic),
            //    WriteIndented = true
            //};
            string result = JsonConvert.SerializeObject(teams);
            return result;

        }

        Player SelectPlayerFromBasket(Team team, List<Player> basket)
        {
            int maxScore = -1;
            int choosenIndex = -1;

            // good keeper is keeper rated > 3
            bool hasKeeper = team.players.Any(c => c.Propes[PropTypes.Keeper] > 6);

            foreach (Player player in basket)
            {
                var playScoreForTeam = 0;
                foreach (var item in player.Propes)
                {
                    playScoreForTeam += item.Value * (int)(team.MyWeiths is null ? 1 : team.MyWeiths[item.Key]);
                };

                if (playScoreForTeam > maxScore)
                {
                    maxScore = playScoreForTeam;
                    choosenIndex = basket.IndexOf(player);
                }
            }

            Player selectedPlayer = basket[choosenIndex];

            basket.RemoveAt(choosenIndex);

            return selectedPlayer;
        }


        public class Player
        {
            public string PlayerID { get; set; }
            public int Score { get; set; }

            public Dictionary<PropTypes, int> Propes { get; set; } = new Dictionary<PropTypes, int>();

            public Player(string id, int _b, int _sh, int _st, int _kee)
            {
                PlayerID = id;
                Propes.Add(PropTypes.Boal, _b);
                Propes.Add(PropTypes.Shot, _sh);
                Propes.Add(PropTypes.Stamina, _st);
                Propes.Add(PropTypes.Keeper, _kee);

                Score = Propes.Sum(c => c.Value);
            }

            public static List<Player> CreateTestBasket(int num)
            {
                Random rnd = new Random();

                List<Player> players = new List<Player>();

                for (int i = 0; i < num; i++)
                {
                    players.Add(new Player(RandomString(4), rnd.Next(1, 10), rnd.Next(1, 10), rnd.Next(1, 10), rnd.Next(1, 10)));
                }

                return players;
            }

            public static string RandomString(int length)
            {
                Random rnd = new Random();
                const string chars1 = "ВГДКЛМНХ";
                const string chars2 = "АОЭЮЯИЕЫ";

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < length; i++)
                {
                    if (i % 2 == 0)
                        sb.Append(chars1[rnd.Next(chars1.Length)]);
                    else
                        sb.Append(chars2[rnd.Next(chars1.Length)]);

                }

                return sb.ToString();

                //var strnew string(Enumerable.Repeat(chars1, length/2)
                //    .Select(s => s[rnd.Next(s.Length)]).ToArray());
            }

        }

        public struct Prop
        {
            public PropTypes Name { get; set; }
            public int Val { get; set; }
            public double Weight { get; set; }

        }

        public enum PropTypes
        {
            Boal,
            Shot,
            Stamina,
            Keeper
        }

        public class Team
        {
            public char Name { get; set; }
            public int AvrScore { get; set; }
            public List<Player> players { get; set; } = new List<Player>();

            public Dictionary<PropTypes, double> MyWeiths { get; set; }

            public Dictionary<PropTypes, int> PropsScore { get; set; }

            public Team()
            {
                MyWeiths = new Dictionary<PropTypes, double>();
                MyWeiths.Add(PropTypes.Keeper, 1);
                MyWeiths.Add(PropTypes.Boal, 1);
                MyWeiths.Add(PropTypes.Shot, 1);
                MyWeiths.Add(PropTypes.Stamina, 1);
            }

            internal void GetTeamScore()
            {
                PropsScore = new Dictionary<PropTypes, int>();
                foreach (var item in players[0].Propes)
                {
                    PropsScore.Add(item.Key, (int)players.Average(c => c.Propes[item.Key]));
                }
                AvrScore = PropsScore.Sum(c => c.Value);
            }
        }

        public class RequestSet
        {
            public int TeamsCount { get; set; }
            public List<Player> Players { get; set; }
        }



    }

}